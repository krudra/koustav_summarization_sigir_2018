In this paper, we have used three disaster related datasets: Nepal earthquake, Typhoon Hagupit, Pakistan flood. These datasets were prepared by research group at QCRI. We have taken their dataset and performed this study. Details about the paper 'Twitter as a Lifeline: Human-annotated Twitter Corpora for NLP of Crisis-related Messages' and dataset can be found at: http://crisisnlp.qcri.org/lrec2016/lrec2016.html

However, this data consists of all the tweet-ids and there is no class specific separation. In this paper, we have used AIDR classifier to classify the data into different relevant classes. This directory contains classwise tweet-ids from three events.

Ground Truth Summaries
-----------------------
We have prepared the ground truth summaries following the instructions of Document Understanding Conferences(DUC). 5 graduate students participated in this task. If you need ground truth summaries kindly sent a mail to rudra@l3s.de and pawang@cse.iitkgp.ac.in.

If you are using the dataset of this paper, kindly cite the following article:

Koustav Rudra, Pawan Goyal, Niloy Ganguly, Prasenjit Mitra, and Muhammad Imran. 2018. Identifying Sub-events and Summarizing Disaster-Related Information from Microblogs. In The 41st International ACM SIGIR Conference on Research & Development in Information Retrieval (SIGIR '18). ACM, New York, NY, USA, 265-274. DOI: https://doi.org/10.1145/3209978.3210030

@inproceedings{Rudra:2018:ISS:3209978.3210030,
 author = {Rudra, Koustav and Goyal, Pawan and Ganguly, Niloy and Mitra, Prasenjit and Imran, Muhammad},
 title = {Identifying Sub-events and Summarizing Disaster-Related Information from Microblogs},
 booktitle = {The 41st International ACM SIGIR Conference on Research \&\#38; Development in Information Retrieval},
 series = {SIGIR '18},
 year = {2018},
 isbn = {978-1-4503-5657-2},
 location = {Ann Arbor, MI, USA},
 pages = {265--274},
 numpages = {10},
 url = {http://doi.acm.org/10.1145/3209978.3210030},
 doi = {10.1145/3209978.3210030},
 acmid = {3210030},
 publisher = {ACM},
 address = {New York, NY, USA},
 keywords = {class-based summarization, high-level summarization, humanitarian classes, situational information, sub-event detection},
}
