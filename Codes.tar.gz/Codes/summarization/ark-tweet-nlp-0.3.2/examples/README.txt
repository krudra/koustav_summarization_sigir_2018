The following commands should all work on the examples.

./runTagger.sh examples/casual.txt
./runTagger.sh --output-format conll examples/casual.txt
./runTagger.sh examples/example_tweets.txt
./runTagger.sh examples/tweets.jsonline
./runTagger.sh --input-field 4 examples/bill_nye_tho.txt
