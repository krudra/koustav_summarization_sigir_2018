################################################################# Concept extraction ##########################################################################
How to run: python extract_terms.py <input file> <place file> <output file>
Inputs:	1. input file format => Tweet ID \t Tweet \t Confidence score
	2. Place file contains information about locations
	3. output file contains concept details

Sample run: python extract_terms.py infrastructure_20150426.txt nepal_place.txt infrastructure_concept_20150426.txt

################################################################# Summarization ###############################################################################
How to run: python subevent_summary.py <input concept file> <input parse file> <input event tagged file> <place file> <keyword> <date> <word length>

Sample run: python subevent_summary.py infrastructure_concept_20150426.txt infrastructure_parsed_20150426.txt infrastructure_ner_20150426.txt nepal_place.txt infrastructure 20150426 200

################################################################# High Level Summary ##########################################################################
How to run: python general_subevent_summary.py <keyterm> <place> <date> <word length>

Sample run: python high_subevent_summary.py Nepal nepal_place.txt 20150426 200

Create two separate directories 1. concept_extraction and 2. parsed_event_files. Put all the relevant class specific files from all the datasets into these two directories
